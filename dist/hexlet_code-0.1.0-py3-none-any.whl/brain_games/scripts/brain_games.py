#!/usr/bin/env python

def brain_welcome():
    print('Welcome to the Brain Games!')


if __name__ == '__main__':
    brain_welcome()